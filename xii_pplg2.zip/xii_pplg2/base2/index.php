<?php

function tembak(){
    echo "Aku anak cerdas, tubuhku kuat\n";
};

// trigger
tembak();

// function with 
// no need to identify datatype
function dor(){
    return 9;
}

// if u using function,
// this function becomes variable
echo dor();

?>