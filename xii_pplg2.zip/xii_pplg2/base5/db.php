<?php

$db = mysqli_connect(
    "localhost", // hostingname
    "root", //username
    "", //password
    "xii_pplg2" // db name
);

// connect_errno = ditanya sama servernya (error kagak?)
if($db->connect_errno == 0){
    return "Database Terkoneksi";
}else{
    return "Database tidak terkoneksi";
}
?>