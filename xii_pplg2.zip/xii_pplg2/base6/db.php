<?php

$db = mysqli_connect(
    "localhost", // hostingname
    "root", //username
    "", //password
    "xii_pplg2" // db name
);

?>