<!-- pengolahan data -->
<?php
include 'db.php'; //disertakan

$data = mysqli_query(
    $db,
    "SELECT * FROM jadwal"
);

?>
<!-- pengolahan data -->
<!-- tampilan -->
<html>
    <head>
        <title>Guru</title>
    </head>
    <body>
        <h1>yaudah</h1>
        <a href="tambah_guru.php">tambah</a>
        <table border=1>
            <tr>
                <th>No</th>
                <th>Mata Pelajaran</th>
                <th>Nama Guru</th>
                <th>Hari</th>
            </tr>
        <?php
        foreach($data as $x){
            ?>
            <tr>
                <td><?= $x['no'] ?></td>
                <td><?= $x['mata_pelajaran'] ?></td>
                <td><?= $x['nama_guru'] ?></td>
                <td><?= $x['hari'] ?></td>
            </tr>
            <?php
            // echo $x['no'];
            // echo $x['mata_pelajaran'];
            // echo $x['nama_guru'];
            // echo $x['hari'];
        }
        ?>
        </table>
    </body>
</html>
<!-- tampilan -->