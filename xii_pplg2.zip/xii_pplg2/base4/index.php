<?php
// tipe data map
// sama kaya list tapi lebih keren

// masing masing value punya key

// list
$lama = [1, "Mr. Jaka", "React Native"];
// memanggil menggunakan index (01234)
echo $lama [1];

// map
$baru = [
    "no" => 1,
    "nama" => "Mr. Jaka",
    "matpel" => "React Native"
];
// key => value
echo $baru["nama"];

?>