<?php

function angka1(){
    echo 17; // echo berfungsi untuk menampilkan
}

function angka2(){
    return 17; //  return berfungsi untuk menjadikan fungsi bernilai
}

function angka3( $data ){
    echo "<br>";
    echo "dataku =", $data;
}

$umur = 17;
if (angka2() >= 17){
    echo "dapat KTP";
}else{
    echo "ga dapet KTP";
}

angka3("blablabla");

?>