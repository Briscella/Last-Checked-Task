<?php
// super global variabel
// buat kkm 78 keatas lulus

// jadi tampilannya, nama, lulus atau tidak lulus
function cek_data($data){
    if(isset($_GET[$data]) == true){
        return $_GET[$data];
    }else{
        return "no data";
    }
}

function cek_hasil($hasil){
    if($hasil >= 78){
        return "Lulus = $hasil";
    }else{
        return "Tidak Lulus = $hasil";
    }
}
?>
<html>
    <head>
        <title>Cek nilai USK</title>
    </head>
    <body>
        <h1><?php echo cek_data('nama'); ?></h1>
        <h1><?php echo cek_hasil(cek_data('nilai')); ?></h1>
        <hr>
        <form action="" method="get">
            <label>Nama</label>
            <input type="text" name="nama">
            <br>
            <label>Nilai</label>
            <input type="number" name="nilai">
            <br>
            <input type="submit" value="Cek Nilai">
        </form>
    </body>
</html>