<?php
    function cek_data($data){
        if(isset($_GET[$data]) == true){
            if($_GET[$data] == NULL){
                return 0;
            } else {
                return $_GET[$data];
            }
        }else{
            return "no data";
        }
}
?>

<html>
    <head>
        <title>Kalkulator</title>
    </head>
    <body>
        <h1>Angka 1 = </h1>
        <h1>Angka 2 = </h1>
        <h1>Hasil = </h1>
        <hr>
        <form action="" method="get">
            <label> Angka 1</label>
            <input type="number" name="angka1">
            <br>
            <label>Angka 2</label>
            <input type="number" name="angka2">
            <br>
            <input type="submit" value="tambah">
        </form>
    </body>
</html>