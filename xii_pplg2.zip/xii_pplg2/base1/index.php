<?php
// cara mengambi semua data dalam table
// select * from table_name

// cara mengisi table
// instert into table_name values(
// 1, 'Olahraga', 'Mr Galih', 'Kamis'
// )

$x = mysqli_connect(
    "localhost",
    "root",
    "",
    "xii_pplg2"
);

echo var_dump($x);

?>
<html>
    <head>
        <title>PHP MYSQL 1</title>
    </head>
    <body>
        
    </body>
</html>